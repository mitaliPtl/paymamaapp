<?php
if (!defined('BASEPATH'))
  exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

class MoneyTransferApi extends BaseController {
    /**
     * This is default constructor of the class
     */
    public function __construct() {
      parent::__construct();        
      $this->load->model('loginApi_model');
      $this->load->model('transactions_model');
      $this->load->model('moneyTransferApi_model');
      $this->load->model('rechargeApi_model');
      $this->load->model('operatorApi_model');
      $this->load->model('apiLog_model');
      $this->load->helper('file');
    }

    public function index() {
    }

    public function authenticateUser($data){
      //autheticate user by token details begin
      if (!empty($data['token']) && !empty($data['user_id']) && !empty($data['role_id'])) {
        $user_id= $data['user_id'];
        $role_id= $data['role_id'];

          //authenticate user with their details
        if(!$this->loginApi_model->authenticateUser($data['user_id'],$data['role_id'],$data['token'])){
          $response = array(
            'status' => "false",
            'msg' => "Authetication failure with invalid token",
            'result' => null
          );
          echo json_encode($response);
          exit;
        }
      }else{//if proper input not getting from the application           
        $response = array(
          'status' => "false",
          'msg' => "Authetication Failure",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //autheticate user by token details end
  }

  public function getSenderDetails() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data); 

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'getSenderDetails';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'transaction_type' => 'IMPS'
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);  
        $result =  json_decode($result, true);
        curl_close($ch);
        /*echo "URL:".$url."<br/>";
        echo "Post Data:".json_encode($parameters)."<br/>";
        echo "Result: ".$result."";*/
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else if($api_details->api_id == "9"){ //eko 
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;      
        echo "URL: ".$url = "https://staging.eko.in:25004/ekoapi/v1/customers/mobile_number:8341322633?initiator_id=".$data['sender_mobile_number'];
        $result = $this->doCurlCallEko($url,"","GET");      
        $result =  json_decode($result, true);
        if($result['response_status_id'] == 0){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['message'],
            'result' => $result
          );
        }
        echo json_encode($response);
        exit;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function createSender() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'registerSender';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'sender_name' => $data['first_name']." ".$data['last_name'],
          'sender_pin_code' => $data['pincode'],
          'transaction_type' => 'IMPS',
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'manireport'=>$re,
            'result' => $result
            
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else if($api_details->api_id == "9"){ //eko 
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;      
        $url = "https://staging.eko.in:25004/ekoapi/v1/customers/mobile_number:8341322633";
        $post_data = array(
          'initiator_id' => $data['sender_mobile_number'],//'8341322633',
          'name' => $data['first_name']." ".$data['last_name']
        );  
        $parameters = http_build_query($post_data);
        $result = $this->doCurlCallEko($url,$parameters,"PUT");      
        $result =  json_decode($result, true);
        
        /*$request = new HttpRequest();
        $request->setUrl("https://staging.eko.in:25004/ekoapi/v1/customers/mobile_number:".$data['sender_mobile_number']);
        $request->setMethod(HTTP_METH_PUT);

        $request->setHeaders(array(
          'postman-token' => '89ce1baf-531e-e42b-dbf8-102be0d9e5a1',
          'cache-control' => 'no-cache',
          'secret-key-timestamp' => '1516705204593',
          'secret-key' => 'MC6dKW278tBef+AuqL/5rW2K3WgOegF0ZHLW/FriZQw=',
          'content-type' => 'application/x-www-form-urlencoded',
          'developer_key' => 'becbbce45f79c6f5109f848acd540567'
        ));

        $request->setContentType('application/x-www-form-urlencoded');
        $request->setPostFields(array(
          'initiator_id' => '8341322633',
          'name' => $data['first_name']." ".$data['last_name']
        ));

        try {
          $response = $request->send();
          $result = $response->getBody();
        } catch (HttpException $ex) {
          $result = $ex;
        }*/
        if($result['response_status_id'] == 0){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['message'],
            'result' => $result
          );
        }
        echo json_encode($response);
        die;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }

    echo json_encode($response);

    exit;  
  }

  public function verifySenderRegistration() {
    $input =  file_get_contents('php://input'); 
    $data =  json_decode($input, true);        
    //$data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'verifySender';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'otp' => $data['otp'],
          'transaction_type' => 'IMPS',
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] != "0"){
          $result['response_description'] = "Invalid OTP. Enter valid OTP or Resend OTP.";
        }
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function resendOTP() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'resendSenderOTP';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'transaction_type' => 'IMPS',
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;  
  }

  public function getRecipientList() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'getRecipientList';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'transaction_type' => 'IMPS',
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function getRecipientDetails() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'getRecipient';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'recipient_id'=>$data['recipient_id'],
          'transaction_type' => 'IMPS',
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function getBankList() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'getBankList';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),     
          'type' => 'ALL'         
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function addRecipient() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'addRecipient';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),       
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'recipient_name'=>$data['recipient_name'],
          'recipient_mobile_number'=>$data['recipient_mobile_number'], 
          'bank_account_number'=>$data['bank_account_number'],
          'bank_code'=>$data['bank_code'],        
          'ifsc'=>$data['ifsc'],
          'transaction_type' => 'IMPS'        
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);  
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] == "0"){
          //add recepient info begin
          $recipientInfo = array(
            'recipient_id' => $this->isValid($result['recipient_details']['recipient_id']),
            'recipient_name' => $this->isValid($result['recipient_details']['recipient_name']),
            'bank_name' => $this->isValid($result['recipient_details']['bank_name']),
            'bank_code' => $this->isValid($result['recipient_details']['bank_code']),
            'bank_account_number' => $this->isValid($result['recipient_details']['bank_account_number']),
            'ifsc' => $this->isValid($result['recipient_details']['ifsc']),  
            'recipient_status' => $this->isValid($result['recipient_details']['recipient_status']),
            'is_verified' => $this->isValid($result['recipient_details']['is_verified']),       
            'verified_name' => $this->isValid($result['recipient_details']['verified_name']),
            'recipient_mobile_number' => $this->isValid($result['recipient_details']['recipient_mobile_number'])
          );
          $this->moneyTransferApi_model->addNewRecepient($recipientInfo);
          //add recepient info end
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function deleteRecipient() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'deleteRecipient';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),       
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'recipient_id'=>$data['recipient_id'],
          'transaction_type' => 'IMPS'        
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        if($result['response_code'] == "0"){
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function verifyBankAccount() {        
    $data =  json_decode(file_get_contents('php://input'), true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $user_id=$data['user_id'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end
      
      $last_order_id = file_get_contents("admin/txn_order_id.txt");
      $sno_order_id  =intval($last_order_id)+1;            
      $order_id ="SP".$sno_order_id;              
     
      
      //check balance of user begin
      $smartpay=9;
      $apptblsmt= $this->transactions_model->getapptab($smartpay);
      $smartpay=8;
      $apptblpay= $this->transactions_model->getapptab($smartpay);
      $amount = $apptblsmt->value;
      $operator_id = $data['operatorID'];
      $user_id= $data['user_id'];
      $role_id= $data['role_id'];
      $userbalance = $this->rechargeApi_model->getUserBalance($data['user_id']);
      if ($userbalance) {
        $wallet_balance = $userbalance->wallet_balance;
        $min_balance = $userbalance->min_balance;
        $user_package_id = $userbalance->package_id;
        if(is_numeric($wallet_balance) && is_numeric($min_balance) && is_numeric($amount) && $wallet_balance-$amount < $min_balance){
          $response = array(
              'status' => "false",
              'msg' => "Insufficient balance",
              'result' => null
          );
          echo json_encode($response);
          exit;
        }else if(!is_numeric($wallet_balance) || !is_numeric($min_balance) || !is_numeric($amount)){
          $response = array(
              'status' => "false",
              'msg' => "Invalid amount details.",
              'result' => null
          );
          echo json_encode($response);
          exit;
        }else{//get all commission details by package id
          $commissionDtl = $this->rechargeApi_model->getCommissionDetails($user_package_id,$service_id,$operator_id,$amount);              
          if ($commissionDtl) {

            if($commissionDtl->commission_type == "Rupees"){
              
              $admin_commission = $commissionDtl->admin_commission;
              $md_commission = $commissionDtl->md_commission;
              $api_commission = $commissionDtl->api_commission;
              $distributor_commission = $commissionDtl->distributor_commission;
              $retailer_commission = $commissionDtl->retailer_commission;
              //susmitha commision cal
              $ccf=$commissionDtl->ccf_commission;
              $charge = $commissionDtl->retailer_commission;
              $cashback=$ccf-$charge;
              //cashback update to trans table based on order_id
              $app    =$this->rechargeApi_model->getTDS();
              $TDS     =$cashback*$app->value;
              $PayableCharge = $charge+$TDS;
              $totalAmount=$amount+$PayableCharge;
              
            }else if($commissionDtl->commission_type == "Percent"){
              $admin_commission = ($amount*$commissionDtl->admin_commission)/100;
              $md_commission = ($amount*$commissionDtl->md_commission)/100;
              $api_commission = ($amount*$commissionDtl->api_commission)/100;
              $distributor_commission = ($amount*$commissionDtl->distributor_commission)/100;
              $retailer_commission = ($amount*$commissionDtl->retailer_commission)/100;
            }else if($commissionDtl->commission_type == "Range"){
              if($commissionDtl->admin_commission_type == "Rupees")
                $admin_commission = $commissionDtl->admin_commission;
              else
                $admin_commission = ($amount*$commissionDtl->admin_commission)/100;
              if($commissionDtl->md_commission_type == "Rupees")
                $md_commission = $commissionDtl->md_commission;
              else
                $md_commission = ($amount*$commissionDtl->md_commission)/100;
              if($commissionDtl->distributor_commission_type == "Rupees")
                $distributor_commission = $commissionDtl->distributor_commission;
              else
                $distributor_commission = ($amount*$commissionDtl->distributor_commission)/100;
              if($commissionDtl->retailer_commission_type == "Rupees")
                $retailer_commission = $commissionDtl->retailer_commission;
              else
                $retailer_commission = ($amount*$commissionDtl->retailer_commission)/100;
                $api_commission = $commissionDtl->api_commission;
            }
          }
        }
      }else{
        $response = array(
            'status' => "false",
            'msg' => "Error while retriving balance",
            'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check balance of user end
      
      //if all above conditions valid then update order id in file
      $this->writeTxnOrderID($sno_order_id);  
       
        
      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'verifyBankAccount';
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),      
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'wallet_id'=>'GoWalletSmartPay',
          'bank_account_number'=>$data['bank_account_number'],
          'bank_code'=>$data['bank_code'],
          'ifsc'=>$data['ifsc'],
          'reference_number'=>$data['reference_number'],
          'transaction_type' => 'IMPS'        
        );        
        $parameters = json_encode($post_data);
        $result = $this->doCurlCall($url,$parameters);      
        $result =  json_decode($result, true);
        curl_close($ch);
        //save api log details begin
        $api_info = array(
          'service_id' => $service_id."", 
          'api_id' => $api_details->api_id."", 
          'api_name' => $api_details->api_name."",  
          'api_method' => "doFundTransfer",
          'api_url' => $url."", 
          'order_id' => $order_id."", 
          'user_id' => $user_id."",  
          'request_input' => $parameters."",
          'request' => $parameters."",         
          'response' => $result_json."",
          'access_type' => "APP",
          'updated_on'=>date('Y-m-d H:i:s'),
        );
        $api_log_id = $this->apiLog_model->addApiLogDetails($api_info);
        //save api log details end
        //update balance after deduction begin
          //$updatedBalance = $wallet_balance-$amount; 
          $updatedBalance = $wallet_balance-$apptblsmt->value;
          //insert DEBIT txn into tbl_wallet_trans_dtls table
          $wallet_trans_info = array(
            'service_id' =>$service_id,
            'order_id' => $this->isValid($order_id), 
            'user_id' => $user_id, 
            'operator_id' => $operator_id,
            'api_id' => $api_details->api_id,
            //'transaction_status' => $this->isValid($result['transaction_status']),
            'transaction_type' => "DEBIT",
            'payment_type' => "SERVICE",
            'payment_mode' => "Bank Verification Charges",
            'transaction_id' => $this->isValid($result['transaction_id']),               
            'trans_date' => date("yy-m-d H:i:s"),  
            'total_amount' =>$apptblsmt->value,
            'charge_amount' => "0.00",
            'balance' => $updatedBalance,
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
          //update balance into users table                           
          $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
          //update balance after deduction end
        if($result['response_code'] == "0"){
          $trans_info = array(
            'transaction_id' => $this->isValid($result['transaction_id']),
            'operator_id'=>$operator_id,
            'service_id' =>$service_id, 
            'api_id' =>$api_details->api_id,
            'trans_date' => date("yy-m-d H:i:s"),
            'order_id' => $this->isValid($order_id),  
            'mobileno' => $this->isValid($result['sender_mobile_number']), 
            'user_id' => $this->isValid($user_id),          
            'total_amount' =>$apptblsmt->value,
            'bank_transaction_id' => $this->isValid($result['transaction_id']), //add
            'imps_name' => $this->isValid($result['imps_name']), //add
            // 'recipient_id' => $this->isValid($result['recipient_id']), //add
            'charges_tax' => $this->isValid($result['charges_tax'])/100, //add

            // 'commission' => $this->isValid($result['commission']), //add
            // 'commission_tax' => $this->isValid($result['commission_tax']), //add
            // 'commission_tds' => $this->isValid($result['commission_tds']), //add
            'debit_amount' => $this->isValid($result['debit_amount']),
            'balance' => $this->isValid($result['balance'])/100,
            'order_status' => $this->isValid("SUCCESS"),
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          $txn_id = $this->transactions_model->addNewTransaction($trans_info);
          //update balance based on api id in api setting table developed by susmitha start
          $currentapibal=$this->isValid($result['balance'])/100;
          $data = array('balance'=>$currentapibal);
           $this->apiLog_model->update_api_amount($data,$api_details->api_id);
         //update balance based on api id in apisetting table developed by susmitha end 
          

          //commission wallet txn begin
          if(is_numeric($role_id) && intval($role_id) <= 4){                
            $walletUserID = $user_id;
            $walletRoleID = $role_id;
            $isUserBalanceUpdated = false;
            for($i=$walletRoleID;$i>=1;$i--){                
              if($i==2 ||$i==3 || $i==4 ){
                $isUserBalanceUpdated = true;
                $userParentID = $this->rechargeApi_model->getUserParentID($walletUserID);
                if ($isUserBalanceUpdated && $userParentID && ($userParentID->roleId==2|| $userParentID->roleId==3||$userParentID->roleId==4)) {
                  $walletUserID = $userParentID->userId;
                  $walletRoleID = $userParentID->roleId;
                  $updatedBalance = $userParentID->wallet_balance;
                }
                continue;
              }
              $walletAmt = 0;
              $walletBal = 0;                 
              $userParentID = $this->rechargeApi_model->getUserParentID($walletUserID);
              if ($isUserBalanceUpdated && $userParentID) {
                $walletUserID = $userParentID->userId;
                $walletRoleID = $userParentID->roleId;
                $updatedBalance = $userParentID->wallet_balance;
              }
              /*echo "Wallet User ID:".$walletUserID." Role ID:".$walletRoleID."<br/>";
              echo "Retailer Commision:".$retailer_commission."Dist.:".$distributor_commission."Admin.:".$admin_commission."<br/>";*/
              // if($walletRoleID == 4){ //Retailer
              //   $walletAmt = $retailer_commission;
              //   $walletBal = $updatedBalance+$retailer_commission;
              // }
              /*else if($walletRoleID == 3){ //FOS
                $walletAmt = $distributor_commission;
                $walletBal = $updatedBalance+$distributor_commission;
              }*/
              // else if($walletRoleID == 2){ //Distributor
              //   $walletAmt = $distributor_commission;
              //   $walletBal = $updatedBalance+$distributor_commission;
              //}

               if($walletRoleID == 1){ //Admin
                $walletAmt = $apptblsmt->value-$apptblpay->value;
                $walletBal = $updatedBalance+($apptblsmt->value-$apptblpay->value);
              }
              if(is_numeric($walletAmt) && is_numeric($walletBal)){
                $transType = "CREDIT";
                if($walletAmt < 0){
                  $transType = "DEBIT";
                }
                $wallet_trans_info = array(
                  'service_id' => $service_id,
                  'order_id' => $this->isValid($order_id), 
                  'user_id' => $walletUserID, 
                  'operator_id' => $operator_id,
                  'api_id' => $api_details->api_id,
                  'transaction_status' => $this->isValid($result['transaction_status']),
                  'transaction_type' => $transType,
                  'payment_type' => "COMMISSION",
                  'payment_mode' => "Commission by bank verification",
                  'transaction_id' => $this->isValid($result['transaction_id']),               
                  'trans_date' => date("yy-m-d H:i:s"),  
                  'total_amount' => abs($walletAmt),
                  'charge_amount' => "0.00",
                  'balance' => $walletBal,
                  'updated_on'=>date('Y-m-d H:i:s'),
                );
                $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
                //update balance into users table                           
                $updateBalQry = $this->rechargeApi_model->updateUserBalance($walletUserID,$walletBal);
                //update balance after deduction end
              }
              $isUserBalanceUpdated = true;
            }
          }
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
          );
        }else{
          $trans_info = array(
            'transaction_id' => $this->isValid($result['transaction_id']),
            'operator_id'=>$operator_id,
            'service_id' =>$service_id, 
            'api_id' =>$api_details->api_id,
            'trans_date' => date("yy-m-d H:i:s"),
            'order_id' => $this->isValid($order_id),  
            'mobileno' => $this->isValid($result['sender_mobile_number']), 
            'user_id' => $this->isValid($user_id),          
            'total_amount' =>$apptblsmt->value,
            'bank_transaction_id' => $this->isValid($result['transaction_id']), //add
            'imps_name' => $this->isValid($result['imps_name']), //add
            // 'recipient_id' => $this->isValid($result['recipient_id']), //add
            'charges_tax' => $this->isValid($result['charges_tax'])/100, //add

            // 'commission' => $this->isValid($result['commission']), //add
            // 'commission_tax' => $this->isValid($result['commission_tax']), //add
            // 'commission_tds' => $this->isValid($result['commission_tds']), //add
            'debit_amount' => $this->isValid($result['debit_amount']),
            'balance' => $this->isValid($result['balance'])/100,
            'order_status' => $this->isValid("FAILED"),
            'transaction_msg'=>$result['response_description'],
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          $txn_id = $this->transactions_model->addNewTransaction($trans_info);
          $userbalance = $this->rechargeApi_model->getUserBalance($user_id);
          $wallet_balance=$userbalance->wallet_balance;
          $updatedBalance = $wallet_balance+$apptblsmt->value;
          //insert DEBIT txn into tbl_wallet_trans_dtls table
          $wallet_trans_info = array(
            'service_id' =>$service_id,
            'order_id' => $this->isValid($order_id), 
            'user_id' => $user_id, 
            'operator_id' => $operator_id,
            'api_id' => $api_details->api_id,
            //'transaction_status' => $this->isValid($result['transaction_status']),
            'transaction_type' => "CREDIT",
            'payment_type' => "SERVICE",
            'payment_mode' => "Bank Verification Charges",
            'transaction_id' => $this->isValid($result['transaction_id']),               
            'trans_date' => date("yy-m-d H:i:s"),  
            'total_amount' =>$apptblsmt->value,
            'charge_amount' => "0.00",
            'balance' => $updatedBalance,
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
          //update balance into users table                           
          $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
          //update balance after deduction end
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;   
  }

  public function doFundTransfer() {    
    $input =  file_get_contents('php://input'); 
    $data =  json_decode($input, true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      $last_order_id = file_get_contents("admin/txn_order_id.txt");
      $sno_order_id  =intval($last_order_id)+1;            
      $order_id ="SP".$sno_order_id;


      if($api_details->api_id == "8" && floatval($data['transaction_amount']) > 5000){ //calling multi fund transfer API
        $this->doMultipleFundTransfer(file_get_contents('php://input'));
        die;
      }

      //check balance of user begin
      $amount = $data['transaction_amount'];
      $operator_id = $data['operatorID'];
      $user_id= $data['user_id'];
      $role_id= $data['role_id'];
     
      $userbalance = $this->rechargeApi_model->getUserBalance($data['user_id']);
      if ($userbalance) {
        $wallet_balance = $userbalance->wallet_balance;
        $min_balance = $userbalance->min_balance;
        $user_package_id = $userbalance->package_id;
        //susmitha commision cal
        $commissiondet = $this->rechargeApi_model->getcommission($service_id,$user_package_id,$operator_id,$amount);
        $ccf=$commissiondet->ccf_commission;
        $charge = $commissiondet->retailer_commission;
         $cashback=$ccf-$charge;
        //cashback update to trans table based on order_id
        $app    =$this->rechargeApi_model->getTDS();
        $TDS     =$cashback*($app->value/100);
        $PayableCharge = $charge+$TDS;
        $totalAmount=$amount+$PayableCharge;
        if(is_numeric($wallet_balance) && is_numeric($min_balance) && is_numeric($totalAmount) && $wallet_balance-$totalAmount < $min_balance){
          $response = array(
              'status' => "false",
              'msg' => "Insufficient balance",
              'result' => null
          );
          echo json_encode($response);
          exit;
        }else if(!is_numeric($wallet_balance) || !is_numeric($min_balance) || !is_numeric($totalAmount)){
          $response = array(
              'status' => "false",
              'msg' => "Invalid amount details.",
              'result' => null
          );
          echo json_encode($response);
          exit;
        }else{//get all commission details by package id
          $commissionDtl = $this->rechargeApi_model->getCommissionDetails($user_package_id,$service_id,$operator_id,$amount);              
          if ($commissionDtl) {

            if($commissionDtl->commission_type == "Rupees"){
              
              $admin_commission = $commissionDtl->admin_commission;
              $md_commission = $commissionDtl->md_commission;
              $api_commission = $commissionDtl->api_commission;
              $distributor_commission = $commissionDtl->distributor_commission;
              $retailer_commission = $commissionDtl->retailer_commission;
              // //susmitha commision cal
              // $ccf=$commissionDtl->ccf_commission;
              // $charge = $commissionDtl->retailer_commission;
              // $cashback=$ccf-$charge;
              // //cashback update to trans table based on order_id
              // $app    =$this->rechargeApi_model->getTDS();
              // $TDS     =$cashback*$app->value;
              // $PayableCharge = $charge+$TDS;
              // $totalAmount=$amount+$PayableCharge;
              
            }else if($commissionDtl->commission_type == "Percent"){
              $admin_commission = ($amount*$commissionDtl->admin_commission)/100;
              $md_commission = ($amount*$commissionDtl->md_commission)/100;
              $api_commission = ($amount*$commissionDtl->api_commission)/100;
              $distributor_commission = ($amount*$commissionDtl->distributor_commission)/100;
              $retailer_commission = ($amount*$commissionDtl->retailer_commission)/100;
            }else if($commissionDtl->commission_type == "Range"){
              if($commissionDtl->admin_commission_type == "Rupees")
                $admin_commission = $commissionDtl->admin_commission;
              else
                $admin_commission = ($amount*$commissionDtl->admin_commission)/100;
              if($commissionDtl->md_commission_type == "Rupees")
                $md_commission = $commissionDtl->md_commission;
              else
                $md_commission = ($amount*$commissionDtl->md_commission)/100;
              if($commissionDtl->distributor_commission_type == "Rupees")
                $distributor_commission = $commissionDtl->distributor_commission;
              else
                $distributor_commission = ($amount*$commissionDtl->distributor_commission)/100;
              if($commissionDtl->retailer_commission_type == "Rupees")
                $retailer_commission = $commissionDtl->retailer_commission;
              else
                $retailer_commission = ($amount*$commissionDtl->retailer_commission)/100;
                $api_commission = $commissionDtl->api_commission;
            }
          }
        }
      }else{
        $response = array(
            'status' => "false",
            'msg' => "Error while retriving balance",
            'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check balance of user end

      //validate mpin begin
      if(isset($data['mpin']) && !empty($data['mpin'])){
        $userDtls = $this->rechargeApi_model->getValidateMPIN($data['user_id'],$data['mpin']);
        if(!$userDtls){
          $response = array(
            'status' => "false",
            'msg' => "Invalid MPIN",
            'result' => null
          );
          echo json_encode($response);
          exit;
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid MPIN",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //validate mpin end

      //if all above conditions valid then update order id in file
      $this->writeTxnOrderID($sno_order_id);      

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'doFundTransfer';      
        $user_id = $data['user_id'];
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password), 
          'wallet_id'=>'GoWalletSmartPay',     
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'recipient_id'=>$data['recipient_id'],
          'transaction_amount'=>$data['transaction_amount'],
          'reference_number' => $order_id,
          'transaction_type' => $data['transaction_type']         
        );        
        $parameters = json_encode($post_data);
        $result_json = $this->doCurlCall($url,$parameters);  
        //$result = '{"partner_code":"PARTNER1","mobile_number":"","sender_mobile_number":"9029438291","response_code":0,"response_description":"Transfer of Rs. 1500.0 was successful ","recipient_id":553,"transaction_type":"IMPS","transaction_amount":1500,"reference_number":"102","transaction_id":"2430","bank_transaction_id":"907014382642","transaction_status":"C","imps_name":"AADHARSHILA PVT LTD","charges":2000,"charges_tax":360,"commission":1100,"commission_tax":198,"commission_tds":55}';
        $result =  json_decode($result_json, true);     
        curl_close($ch);
        //save api log details begin
        $api_info = array(
          'service_id' => $service_id."", 
          'api_id' => $api_details->api_id."", 
          'api_name' => $api_details->api_name."",  
          'api_method' => "doFundTransfer",
          'api_url' => $url."", 
          'order_id' => $order_id."", 
          'user_id' => $user_id."",  
          'request_input' => $parameters."",
          'request' => $parameters."",         
          'response' => $result_json."",
          'access_type' => "APP",
          'updated_on'=>date('Y-m-d H:i:s'),
        );
        $api_log_id = $this->apiLog_model->addApiLogDetails($api_info);
        //susmitha commision cal
        $commissionDtl = $this->rechargeApi_model->getcommission($service_id,$user_package_id,$operator_id,$amount);
        $ccf=$commissionDtl->ccf_commission;
        $charge = $commissionDtl->retailer_commission;
        $cashback=$ccf-$charge;
        //cashback update to trans table based on order_id
        $app    =$this->rechargeApi_model->getTDS();
        $TDS     =$cashback*($app->value/100);
        $PayableCharge = $charge+$TDS;
        $totalAmount=$amount+$PayableCharge;
        //save api log details end
        //update balance after deduction begin
        //$updatedBalance = $wallet_balance-$amount;
          $updatedBalance = $wallet_balance-$totalAmount; 
          //insert DEBIT txn into tbl_wallet_trans_dtls table
          $wallet_trans_info = array(
            'service_id' =>$service_id,
            'order_id' => $this->isValid($order_id), 
            'user_id' => $user_id, 
            'operator_id' => $operator_id,
            'api_id' => $api_details->api_id,
            'transaction_status' => $this->isValid($result['transaction_status']),
            'transaction_type' => "DEBIT",
            'payment_type' => "SERVICE",
            'payment_mode' => "Money Transfer By Wallet Balance",
            'transaction_id' => $this->isValid($result['transaction_id']),               
            'trans_date' => date("yy-m-d H:i:s"),  
            'total_amount' => $totalAmount,
            'charge_amount' => "0.00",
            'balance' => $updatedBalance,
            'CCFcharges'=>$ccf,
            'Cashback'=>$cashback,
            'TDSamount'=>$TDS,
            'PayableCharge'=>$PayableCharge,
            'FinalAmount'=>$totalAmount,
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
          //update balance into users table                           
          $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
          //update balance after deduction end
        if($result['response_code'] == "0"){
          $trans_info = array(
            'transaction_id' => $this->isValid($result['transaction_id']),
            'transaction_status' => $this->isValid($result['transaction_status']), 
            'service_id' => $service_id, 
            'operator_id'=>$operator_id,
            'api_id' => $api_details->api_id,
            'trans_date' => date("yy-m-d H:i:s"),
            'order_id' => $this->isValid($order_id),  
            'mobileno' => $this->isValid($result['sender_mobile_number']), 
            'user_id' => $this->isValid($user_id),          
            'total_amount' => $this->isValid($result['transaction_amount']),
            'charge_amount' => $this->isValid($result['charges'])/100,
            'transaction_type' => $this->isValid($result['transaction_type']), //add
            'bank_transaction_id' => $this->isValid($result['bank_transaction_id']), //add
            'imps_name' => $this->isValid($result['imps_name']), //add
            'recipient_id' => $this->isValid($result['recipient_id']), //add
            'charges_tax' => $this->isValid($result['charges_tax'])/100, //add
            'commission' => $this->isValid($result['commission'])/100, //add
            'commission_tax' => $this->isValid($result['commission_tax'])/100, //add
            'commission_tds' => $this->isValid($result['commission_tds'])/100, //add
            'debit_amount' => $this->isValid($result['debit_amount'])/100,
            'balance' => $this->isValid($result['balance'])/100,
            'order_status' => $this->isValid("SUCCESS"),
            'transaction_msg'=>$result['response_description'],
            'CCFcharges'=>$ccf,
            'Cashback'=>$cashback,
            'TDSamount'=>$TDS,
            'PayableCharge'=>$PayableCharge,
            'FinalAmount'=>$totalAmount,
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          
              
          $txn_id = $this->transactions_model->addNewTransaction($trans_info);
          //update balance based on api id in api setting table developed by susmitha start
          $currentapibal=$this->isValid($result['balance'])/100;
          $data = array('balance'=>$currentapibal);
           $this->apiLog_model->update_api_amount($data,$api_details->api_id);
          //update balance based on api id in apisetting table developed by susmitha end  
          $money_re=$this->transactions_model->getmoneyreport($txn_id);
          // print_r($money_re);
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result,
            'money'=>$money_re
          );
        

          // //update balance after deduction begin
          // //$updatedBalance = $wallet_balance-$amount;
          //  $updatedBalance = $wallet_balance-$totalAmount; 
          // //insert DEBIT txn into tbl_wallet_trans_dtls table
          // $wallet_trans_info = array(
          //   'service_id' =>$service_id,
          //   'order_id' => $this->isValid($order_id), 
          //   'user_id' => $user_id, 
          //   'operator_id' => $operator_id,
          //   'api_id' => $api_details->api_id,
          //   'transaction_status' => $this->isValid($result['transaction_status']),
          //   'transaction_type' => "DEBIT",
          //   'payment_type' => "SERVICE",
          //   'payment_mode' => "Money Transfer By Wallet Balance",
          //   'transaction_id' => $this->isValid($result['transaction_id']),               
          //   'trans_date' => date("yy-m-d H:i:s"),  
          //   'total_amount' => $totalAmount,
          //   'charge_amount' => "0.00",
          //   'balance' => $updatedBalance
          // );
          // $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
          // //update balance into users table                           
          // $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
          // //update balance after deduction end

          //commission wallet txn begin
          if(is_numeric($role_id) && intval($role_id) <= 4){                
            $walletUserID = $user_id;
            $walletRoleID = $role_id;
            $isUserBalanceUpdated = false;
            for($i=$walletRoleID;$i>=1;$i--){                
              if($i==3 || $i==4 ){
                $isUserBalanceUpdated = true;
                $userParentID = $this->rechargeApi_model->getUserParentID($walletUserID);
                if ($isUserBalanceUpdated && $userParentID && ( $userParentID->roleId==3||$userParentID->roleId==4) ) {
                  $walletUserID = $userParentID->userId;
                  $walletRoleID = $userParentID->roleId;
                  $updatedBalance = $userParentID->wallet_balance;
                }
                continue;
              }
              $walletAmt = 0;
              $walletBal = 0;                 
              $userParentID = $this->rechargeApi_model->getUserParentID($walletUserID);
              if ($isUserBalanceUpdated && $userParentID) {
                $walletUserID = $userParentID->userId;
                $walletRoleID = $userParentID->roleId;
                $updatedBalance = $userParentID->wallet_balance;
              }
              /*echo "Wallet User ID:".$walletUserID." Role ID:".$walletRoleID."<br/>";
              echo "Retailer Commision:".$retailer_commission."Dist.:".$distributor_commission."Admin.:".$admin_commission."<br/>";*/
              // if($walletRoleID == 4){ //Retailer
              //   $walletAmt = $retailer_commission;
              //   $walletBal = $updatedBalance+$retailer_commission;
              // }
              /*else if($walletRoleID == 3){ //FOS
                $walletAmt = $distributor_commission;
                $walletBal = $updatedBalance+$distributor_commission;
              }*/ if($walletRoleID == 2){ //Distributor
                $walletAmt = $distributor_commission;
                $walletBal = $updatedBalance+$distributor_commission;
              }else if($walletRoleID == 1){ //Admin
                $walletAmt = $admin_commission;
                $walletBal = $updatedBalance+$admin_commission;
              }
              if(is_numeric($walletAmt) && is_numeric($walletBal)){
                $transType = "CREDIT";
                if($walletAmt < 0){
                  $transType = "DEBIT";
                }
                $wallet_trans_info = array(
                  'service_id' => $service_id,
                  'order_id' => $this->isValid($order_id), 
                  'user_id' => $walletUserID, 
                  'operator_id' => $operator_id,
                  'api_id' => $api_details->api_id,
                  'transaction_status' => $this->isValid($result['transaction_status']),
                  'transaction_type' => $transType,
                  'payment_type' => "COMMISSION",
                  'payment_mode' => "Commission by Money Transfer",
                  'transaction_id' => $this->isValid($result['transaction_id']),               
                  'trans_date' => date("yy-m-d H:i:s"),  
                  'total_amount' => abs($walletAmt),
                  'charge_amount' => "0.00",
                  'balance' => $walletBal,
                  'updated_on'=>date('Y-m-d H:i:s'),
                );
                $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
                //update balance into users table                           
                $updateBalQry = $this->rechargeApi_model->updateUserBalance($walletUserID,$walletBal);
                //update balance after deduction end
              }
              $isUserBalanceUpdated = true;
            }
          }
          //commission wallet txn end
        }else{
          $trans_info = array(
            'transaction_id' => $this->isValid($result['transaction_id']),
            'transaction_status' => $this->isValid($result['transaction_status']), 
            'service_id' => $service_id, 
            'operator_id'=>$operator_id,
            'api_id' => $api_details->api_id,
            'trans_date' => date("yy-m-d H:i:s"),
            'order_id' => $this->isValid($order_id),  
            'mobileno' => $this->isValid($result['sender_mobile_number']), 
            'user_id' => $this->isValid($user_id),          
            'total_amount' => $this->isValid($result['transaction_amount']),
            'charge_amount' => $this->isValid($result['charges'])/100,
            'transaction_type' => $this->isValid($result['transaction_type']), //add
            'bank_transaction_id' => $this->isValid($result['bank_transaction_id']), //add
            'imps_name' => $this->isValid($result['imps_name']), //add
            'recipient_id' => $this->isValid($result['recipient_id']), //add
            'charges_tax' => $this->isValid($result['charges_tax'])/100, //add
            'commission' => $this->isValid($result['commission'])/100, //add
            'commission_tax' => $this->isValid($result['commission_tax'])/100, //add
            'commission_tds' => $this->isValid($result['commission_tds'])/100, //add
            'debit_amount' => $this->isValid($result['debit_amount'])/100,
            'balance' => $this->isValid($result['balance'])/100,
            'order_status' => $this->isValid("FAILED"),
            'transaction_msg'=>$result['response_description'],
            'updated_on'=>date('Y-m-d H:i:s'),
            
          );
          $txn_id = $this->transactions_model->addNewTransaction($trans_info);
          //update balance after deduction begin
        //$updatedBalance = $wallet_balance-$amount;
          $userbalance = $this->rechargeApi_model->getUserBalance($data['user_id']);
          $wallet_balance=$userbalance->wallet_balance;
          $updatedBalance = $wallet_balance+$totalAmount; 
          //insert DEBIT txn into tbl_wallet_trans_dtls table
          $wallet_trans_info = array(
            'service_id' =>$service_id,
            'order_id' => $this->isValid($order_id), 
            'user_id' => $user_id, 
            'operator_id' => $operator_id,
            'api_id' => $api_details->api_id,
            'transaction_status' => $this->isValid($result['transaction_status']),
            'transaction_type' => "CREDIT",
            'payment_type' => "SERVICE",
            'payment_mode' => "Money Transfer By Wallet Balance",
            'transaction_id' => $this->isValid($result['transaction_id']),               
            'trans_date' => date("yy-m-d H:i:s"),  
            'total_amount' => $totalAmount,
            'charge_amount' => "0.00",
            'balance' => $updatedBalance,
            'updated_on'=>date('Y-m-d H:i:s'),
          );
          $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
          //update balance into users table                           
          $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
          //update balance after deduction end
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result
          );        
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }

  public function doMultipleFundTransfer($input) {        
    $data =  json_decode($input, true);

    $this->authenticateUser($data);

    if(!empty($data['operatorID']) && !empty($data['sender_mobile_number'])){
      //get service details by operator id begin
      $operator_id = $data['operatorID'];
      $serviceDtl = $this->operatorApi_model->getServiceDetailsByOperatorID($operator_id);
      if($serviceDtl){
        $service_id = $serviceDtl[0]->service_id;
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid Service",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //get service details by operator id end 

      //check active api for operator begin
      $api_details = $this->rechargeApi_model->getActiveApiDetails($operator_id,$service_id,"");
      if(!$api_details){
        $response = array(
          'status' => "false",
          'msg' => "API details not configured for operator.Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check active api for operator end

      $last_order_id = file_get_contents("admin/txn_order_id.txt");              
      $sno_order_id  =intval($last_order_id)+1;            
      $order_id ="SP".$sno_order_id;
      //check balance of user begin
      $amount = $data['transaction_amount'];
      $operator_id = $data['operatorID'];
      $user_id= $data['user_id'];
      $role_id= $data['role_id'];
       //min bal calculate
      $charge=$amount*(0.6/100);
      $app    =$this->rechargeApi_model->getTDS();
      $TDS     =$amount*(0.4/100)*($app->value/100);
      $totalcharge=$charge+$TDS;
      $Checkamountinwallet =$amount +$totalcharge;
      $userbalance = $this->rechargeApi_model->getUserBalance($data['user_id']);
      if ($userbalance) {
        $wallet_balance = $userbalance->wallet_balance;
        $min_balance = $userbalance->min_balance;
        $user_package_id = $userbalance->package_id;
        
        if(is_numeric($wallet_balance) && is_numeric($min_balance) && is_numeric($Checkamountinwallet) && $wallet_balance-$Checkamountinwallet < $min_balance){
          $response = array(
              'status' => "false",
              'msg' => "Insufficient balance",
              'result' => null
          );
          echo json_encode($response);
          exit;
        }else if(!is_numeric($wallet_balance) || !is_numeric($min_balance) || !is_numeric($Checkamountinwallet)){
          $response = array(
              'status' => "false",
              'msg' => "Invalid amount details.",
              'result' => null
          );
          echo json_encode($response);
          exit;
        }else{//get all commission details by package id
          /*$commissionDtl = $this->rechargeApi_model->getCommissionDetails($user_package_id,$service_id,$operator_id,$amount);              
          if ($commissionDtl) {
            if($commissionDtl->commission_type == "Rupees"){
              $admin_commission = $commissionDtl->admin_commission;
              $md_commission = $commissionDtl->md_commission;
              $api_commission = $commissionDtl->api_commission;
              $distributor_commission = $commissionDtl->distributor_commission;
              $retailer_commission = $commissionDtl->retailer_commission;
            }else if($commissionDtl->commission_type == "Percent"){
              $admin_commission = ($amount*$commissionDtl->admin_commission)/100;
              $md_commission = ($amount*$commissionDtl->md_commission)/100;
              $api_commission = ($amount*$commissionDtl->api_commission)/100;
              $distributor_commission = ($amount*$commissionDtl->distributor_commission)/100;
              $retailer_commission = ($amount*$commissionDtl->retailer_commission)/100;
            }else if($commissionDtl->commission_type == "Range"){
              if($commissionDtl->admin_commission_type == "Rupees")
                $admin_commission = $commissionDtl->admin_commission;
              else
                $admin_commission = ($amount*$commissionDtl->admin_commission)/100;
              if($commissionDtl->md_commission_type == "Rupees")
                $md_commission = $commissionDtl->md_commission;
              else
                $md_commission = ($amount*$commissionDtl->md_commission)/100;
              if($commissionDtl->distributor_commission_type == "Rupees")
                $distributor_commission = $commissionDtl->distributor_commission;
              else
                $distributor_commission = ($amount*$commissionDtl->distributor_commission)/100;
              if($commissionDtl->retailer_commission_type == "Rupees")
                $retailer_commission = $commissionDtl->retailer_commission;
              else
                $retailer_commission = ($amount*$commissionDtl->retailer_commission)/100;
                $api_commission = $commissionDtl->api_commission;
            }
          }*/
        }
      }else{
        $response = array(
            'status' => "false",
            'msg' => "Error while retriving balance",
            'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //check balance of user end

      //validate mpin begin
      if(isset($data['mpin']) && !empty($data['mpin'])){
        $userDtls = $this->rechargeApi_model->getValidateMPIN($data['user_id'],$data['mpin']);
        if(!$userDtls){
          $response = array(
            'status' => "false",
            'msg' => "Invalid MPIN",
            'result' => null
          );
          echo json_encode($response);
          exit;
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "Invalid MPIN",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //validate mpin end

      //if all above conditions valid then update order id in file
      $this->writeTxnOrderID($sno_order_id);

      if($api_details->api_id == "8"){ //go payment        
        $url = $api_details->api_url.'doMultipleFundTransfers';
        $user_id = $data['user_id'];
        $post_data = array(
          'partner_code' => $api_details->api_token,
          'mobile_number' => $api_details->username,
          'password' => base64_decode($api_details->password),  
          'wallet_id'=>'GoWalletSmartPay',     
          'sender_mobile_number'=>$data['sender_mobile_number'],
          'recipient_id'=>$data['recipient_id'],
          'transaction_amount'=>$data['transaction_amount'],
          'reference_number' => $order_id,
          'transaction_type' => $data['transaction_type']         
        );        
        $parameters = json_encode($post_data);
        $result_json = $this->doCurlCall($url,$parameters);  
        //$result ='{"partner_code":"SMARTPAY","mobile_number":"8341322633","sender_mobile_number":"8333898681","response_code":0,"response_description":"Rs. 6000.00 is debited from you wallet.  ","recipient_id":3492254,"transaction_type":"IMPS","transaction_amount":6000,"reference_number":"6231","fund_transfer_status":[{"transaction_amount":500000,"reference_number":"6231","transaction_id":"12343083","bank_transaction_id":"027913044193","transaction_status":"C","imps_name":"TATI SRIKANTH","charges":4237,"charges_tax":763,"commission":3737,"commission_tax":0,"commission_tds":140,"balance":3879355,"debit_amount":501403,"transaction_date":"05-10-2020 13:07:00","refund_date":null},{"transaction_amount":100000,"reference_number":"6231","transaction_id":"12343084","bank_transaction_id":"027913044206","transaction_status":"C","imps_name":"TATI SRIKANTH","charges":847,"charges_tax":153,"commission":347,"commission_tax":0,"commission_tds":13,"balance":3778689,"debit_amount":100666,"transaction_date":"05-10-2020 13:07:00","refund_date":null}],"uuid":null}';
        $result =  json_decode($result_json, true);     
        curl_close($ch);
        //save api log details begin
        $api_info = array(
          'service_id' => $service_id."", 
          'api_id' => $api_details->api_id."", 
          'api_name' => $api_details->api_name."",  
          'api_method' => "doMultipleFundTransfer",
          'api_url' => $url."", 
          'order_id' => $order_id."", 
          'user_id' => $user_id."",  
          'request_input' => $parameters."",
          'request' => $parameters."",         
          'response' => $result_json."",
          'access_type' => "APP",
          'updated_on'=>date('Y-m-d H:i:s'),
        );
        $api_log_id = $this->apiLog_model->addApiLogDetails($api_info);
        //save api log details end
        if($result['response_code'] == "0"){
          for($i= 0 ; $i < count($result['fund_transfer_status']); $i++){
            //susmitha commision cal
            $cal_amount=$result['fund_transfer_status'][$i]['transaction_amount']/100;
            $commissionDtl = $this->rechargeApi_model->getcommission($service_id,$user_package_id,$operator_id,$cal_amount);
            $ccf=$commissionDtl->ccf_commission;
            $charge = $commissionDtl->retailer_commission;
            $cashback=$ccf-$charge;
            //cashback update to trans table based on order_id
            $app    =$this->rechargeApi_model->getTDS();
            $TDS     =$cashback*($app->value/100);

            $PayableCharge = $charge+$TDS;
            $totalAmount=$cal_amount+$PayableCharge;
            //wallet entry start 
              //update balance after deduction begin
            $userbalance = $this->rechargeApi_model->getUserBalance($data['user_id']);
            $wallet_balance=$userbalance->wallet_balance;
            $updatedBalance = $wallet_balance-$totalAmount; 
            //insert DEBIT txn into tbl_wallet_trans_dtls table
            $wallet_trans_info = array(
              'service_id' => $service_id,
              'order_id' => $this->isValid($order_id), 
              'user_id' => $user_id, 
              'operator_id' => $operator_id,
              'api_id' => $api_details->api_id,
              'transaction_status' => $this->isValid($result['fund_transfer_status'][$i]['transaction_status']),
              'transaction_type' => "DEBIT",
              'payment_type' => "SERVICE",
              'payment_mode' => "COMMISSION",
              'transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['transaction_id']),               
              'trans_date' => date("yy-m-d H:i:s"),  
              'total_amount' => $totalAmount,
              'charge_amount' => "0.00",
              'balance' => $updatedBalance,
              'CCFcharges'=>$ccf,
              'Cashback'=>$cashback,
              'TDSamount'=>$TDS,
              'PayableCharge'=>$PayableCharge,
              'FinalAmount'=>$totalAmount,
              'updated_on'=>date('Y-m-d H:i:s'),
            );
            $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
            //update balance into users table                           
            $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
            //update balance after deduction end
            //Commission details added by ashik begin
            if ($commissionDtl) {
              if($commissionDtl->commission_type == "Rupees"){
                $admin_commission = $commissionDtl->admin_commission;
                $md_commission = $commissionDtl->md_commission;
                $api_commission = $commissionDtl->api_commission;
                $distributor_commission = $commissionDtl->distributor_commission;
                $retailer_commission = $commissionDtl->retailer_commission;
              }else if($commissionDtl->commission_type == "Percent"){
                $admin_commission = ($cal_amount*$commissionDtl->admin_commission)/100;
                $md_commission = ($cal_amount*$commissionDtl->md_commission)/100;
                $api_commission = ($cal_amount*$commissionDtl->api_commission)/100;
                $distributor_commission = ($cal_amount*$commissionDtl->distributor_commission)/100;
                $retailer_commission = ($cal_amount*$commissionDtl->retailer_commission)/100;
              }else if($commissionDtl->commission_type == "Range"){
                if($commissionDtl->admin_commission_type == "Rupees")
                  $admin_commission = $commissionDtl->admin_commission;
                else
                  $admin_commission = ($cal_amount*$commissionDtl->admin_commission)/100;
                if($commissionDtl->md_commission_type == "Rupees")
                  $md_commission = $commissionDtl->md_commission;
                else
                  $md_commission = ($cal_amount*$commissionDtl->md_commission)/100;
                if($commissionDtl->distributor_commission_type == "Rupees")
                  $distributor_commission = $commissionDtl->distributor_commission;
                else
                  $distributor_commission = ($cal_amount*$commissionDtl->distributor_commission)/100;
                if($commissionDtl->retailer_commission_type == "Rupees")
                  $retailer_commission = $commissionDtl->retailer_commission;
                else
                  $retailer_commission = ($cal_amount*$commissionDtl->retailer_commission)/100;
                  $api_commission = $commissionDtl->api_commission;
              }
            }
            //Commission details added by ashik end
            $trans_info = array(
              'transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['transaction_id']),
              'transaction_status' => $this->isValid($result['fund_transfer_status'][$i]['transaction_status']), 
              'service_id' => $service_id,
              'operator_id' => $operator_id,
              'api_id' => $api_details->api_id,
              'trans_date' => date("yy-m-d H:i:s"),
              'order_id' => $this->isValid($order_id),  
              'mobileno' => $this->isValid($result['sender_mobile_number']), 
              'user_id' => $this->isValid($user_id),          
              'total_amount' => $this->isValid($cal_amount),
              'charge_amount' => $this->isValid($result['fund_transfer_status'][$i]['charges'])/100,
              'transaction_type' => $this->isValid($result['transaction_type']), //add
              'bank_transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['bank_transaction_id']), //add
              'imps_name' => $this->isValid($result['fund_transfer_status'][$i]['imps_name']), //add
              'recipient_id' => $this->isValid($result['recipient_id']), //add
              'charges_tax' => $this->isValid($result['fund_transfer_status'][$i]['charges_tax']), //add
              'commission' => $this->isValid($result['fund_transfer_status'][$i]['commission'])/100, //add
              'commission_tax' => $this->isValid($result['fund_transfer_status'][$i]['commission_tax'])/100, //add
              'commission_tds' => $this->isValid($result['fund_transfer_status'][$i]['commission_tds'])/100, //add
              'debit_amount' => $this->isValid($result['fund_transfer_status'][$i]['debit_amount'])/100,
              'balance' => $this->isValid($result['fund_transfer_status'][$i]['balance'])/100,
              'order_status' => $this->isValid("SUCCESS"),
              
              'transaction_msg'=>$result['response_description'],
              'CCFcharges'=>$ccf,
              'Cashback'=>$cashback,
              'TDSamount'=>$TDS,
              'PayableCharge'=>$PayableCharge,
              'FinalAmount'=>$totalAmount,
              'updated_on'=>date('Y-m-d H:i:s'),
            );
            $txn_id = $this->transactions_model->addNewTransaction($trans_info);
            //update balance based on api id in api setting table developed by susmitha start
          $currentapibal=$this->isValid($result['fund_transfer_status'][$i]['balance'])/100;
          $data = array('balance'=>$currentapibal);
           $this->apiLog_model->update_api_amount($data,$api_details->api_id);
           //update balance based on api id in apisetting table developed by susmitha end 
             if($result['fund_transfer_status'][$i]['transaction_status']=='F')
             {
             //update balance after deduction begin
            $userbalance = $this->rechargeApi_model->getUserBalance($data['user_id']);
            $wallet_balance=$userbalance->wallet_balance;
            $updatedBalance = $wallet_balance+$totalAmount; 
            //insert DEBIT txn into tbl_wallet_trans_dtls table
            $wallet_trans_info = array(
              'service_id' => $service_id,
              'order_id' => $this->isValid($order_id), 
              'user_id' => $user_id, 
              'operator_id' => $operator_id,
              'api_id' => $api_details->api_id,
              'transaction_status' => $this->isValid($result['fund_transfer_status'][$i]['transaction_status']),
              'transaction_type' => "CREDIT",
              'payment_type' => "SERVICE",
              'payment_mode' => "COMMISSION",
              'transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['transaction_id']),               
              'trans_date' => date("yy-m-d H:i:s"),  
              'total_amount' => $totalAmount,
              'charge_amount' => "0.00",
              'balance' => $updatedBalance,
              'updated_on'=>date('Y-m-d H:i:s'),
            );
            $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
            //update balance into users table                           
            $updateBalQry = $this->rechargeApi_model->updateUserBalance($user_id,$updatedBalance);
            //update balance after deduction end
            }
            //commission wallet txn begin
            if(is_numeric($role_id) && intval($role_id) <= 4){                
              $walletUserID = $user_id;
              $walletRoleID = $role_id;
              $isUserBalanceUpdated = false;
              for($k=$walletRoleID;$k>=1;$k--){                
                if($k==3 || $k==4 ){
                  $isUserBalanceUpdated = true;
                  $userParentID = $this->rechargeApi_model->getUserParentID($walletUserID);
                  if ($isUserBalanceUpdated && $userParentID && ($userParentID->roleId==3||$userParentID->roleId==4)) {
                    $walletUserID = $userParentID->userId;
                    $walletRoleID = $userParentID->roleId;
                    $updatedBalance = $userParentID->wallet_balance;
                  }
                  continue;
                }
                $walletAmt = 0;
                $walletBal = 0;                 
                $userParentID = $this->rechargeApi_model->getUserParentID($walletUserID);
                 if ($isUserBalanceUpdated && $userParentID ) {
                  $walletUserID = $userParentID->userId;
                  $walletRoleID = $userParentID->roleId;
                  $updatedBalance = $userParentID->wallet_balance;
                }                
                /*if($walletRoleID == 4){ //Retailer
                  $walletAmt = $retailer_commission;
                  $walletBal = $updatedBalance+$retailer_commission;
                }/*else if($walletRoleID == 3){ //FOS
                  $walletAmt = $distributor_commission;
                  $walletBal = $updatedBalance+$distributor_commission;
                }else*/ if($walletRoleID == 2){ //Distributor
                  $walletAmt = $distributor_commission;
                  $walletBal = $updatedBalance+$distributor_commission;
                }else if($walletRoleID == 1){ //Admin
                  $walletAmt = $admin_commission;
                  $walletBal = $updatedBalance+$admin_commission;
                }
                if(is_numeric($walletAmt) && is_numeric($walletBal)){
                  $transType = "CREDIT";
                  if($walletBal < 0){
                    $transType = "DEBIT";
                  }
                  $wallet_trans_info = array(
                    'service_id' => $service_id,
                    'order_id' => $this->isValid($order_id), 
                    'user_id' =>$walletUserID, 
                    'operator_id' => $operator_id,
                    'api_id' => $api_details->api_id,
                    'transaction_status' => $this->isValid($result['fund_transfer_status'][$i]['transaction_status']),
                    'transaction_type' => $transType,
                    'payment_type' => "SERVICE",
                    'payment_mode' => "COMMISSION",
                    'transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['transaction_id']),               
                    'trans_date' => date("yy-m-d H:i:s"),  
                    'total_amount' => $walletAmt,
                    'charge_amount' => "0.00",
                    'balance' => $walletBal,
                    'updated_on'=>date('Y-m-d H:i:s'),
                  );
                  $wallet_txn_id = $this->transactions_model->addNewWalletTransaction($wallet_trans_info);
                  //update balance into users table                           
                  $updateBalQry = $this->rechargeApi_model->updateUserBalance($walletUserID,$walletBal);
                  //update balance after deduction end
                }
                $isUserBalanceUpdated = true;
              }
            }
            //commission wallet txn end
          }
          $money=$this->transactions_model->getmoney_domultiple_report($order_id);
          $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result,
            'money'=>$money
          );
        }else{
          if(isset($result['fund_transfer_status']) && count($result['fund_transfer_status']) > 0)
          {
            for($i= 0 ; $i < count($result['fund_transfer_status']); $i++){
              $trans_info = array(
                'transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['transaction_id']),
                'transaction_status' => $this->isValid($result['fund_transfer_status'][$i]['transaction_status']), 
                'service_id' => $service_id,
                'operator_id' => $operator_id,
                'api_id' => $api_details->api_id,
                'trans_date' => date("yy-m-d H:i:s"),
                'order_id' => $this->isValid($order_id),  
                'mobileno' => $this->isValid($result['sender_mobile_number']), 
                'user_id' => $this->isValid($user_id),          
                'total_amount' => $this->isValid($result['fund_transfer_status'][$i]['transaction_amount'])/100,
                'charge_amount' => $this->isValid($result['fund_transfer_status'][$i]['charges'])/100,
                'transaction_type' => $this->isValid($result['transaction_type']), //add
                'bank_transaction_id' => $this->isValid($result['fund_transfer_status'][$i]['bank_transaction_id']), //add
                'imps_name' => $this->isValid($result['fund_transfer_status'][$i]['imps_name']), //add
                'recipient_id' => $this->isValid($result['recipient_id']), //add
                'charges_tax' => $this->isValid($result['fund_transfer_status'][$i]['charges_tax'])/100, //add
                'commission' => $this->isValid($result['fund_transfer_status'][$i]['commission'])/100, //add
                'commission_tax' => $this->isValid($result['fund_transfer_status'][$i]['commission_tax'])/100, //add
                'commission_tds' => $this->isValid($result['fund_transfer_status'][$i]['commission_tds'])/100, //add
                'debit_amount' => $this->isValid($result['fund_transfer_status'][$i]['debit_amount'])/100,
                'balance' => $this->isValid($result['fund_transfer_status'][$i]['balance'])/100,
                'order_status' => $this->isValid("FAILED"),
                'transaction_msg'=>$result['response_description'],
                'updated_on'=>date('Y-m-d H:i:s'),
              );
              $txn_id = $this->transactions_model->addNewTransaction($trans_info);
            }
          }else{
            $trans_info = array(
              'transaction_id' => $this->isValid($result['transaction_id']),
              'transaction_status' => $this->isValid($result['transaction_status']), 
              'service_id' => $service_id,
              'operator_id' => $operator_id,
              'api_id' => $api_details->api_id,
              'trans_date' => date("yy-m-d H:i:s"),
              'order_id' => $this->isValid($order_id),  
              'mobileno' => $this->isValid($result['sender_mobile_number']), 
              'user_id' => $this->isValid($user_id),          
              'total_amount' => $this->isValid($result['transaction_amount']),
              'charge_amount' => $this->isValid($result['charges'])/100,
              'transaction_type' => $this->isValid($result['transaction_type']), //add
              'bank_transaction_id' => $this->isValid($result['bank_transaction_id']), //add
              'imps_name' => $this->isValid($result['imps_name']), //add
              'recipient_id' => $this->isValid($result['recipient_id']), //add
              'charges_tax' => $this->isValid($result['charges_tax'])/100, //add
              'commission' => $this->isValid($result['commission'])/100, //add
              'commission_tax' => $this->isValid($result['commission_tax'])/100, //add
              'commission_tds' => $this->isValid($result['commission_tds'])/100, //add
              'order_status' => $this->isValid("FAILED"),
              'transaction_msg'=>$result['response_description'],
              'updated_on'=>date('Y-m-d H:i:s'),
            );
            $txn_id = $this->transactions_model->addNewTransaction($trans_info);
          }
      $money=$this->transactions_model->getmoney_domultiple_report($order_id);
          $response = array(
            'status' => "false",
            'msg' => $result['response_description'],
            'result' => $result,
            'money'=>$money
          );
        }
      }else{
        $response = array(
          'status' => "false",
          'msg' => "API implementation under process. Please contact administrator.",
          'result' => null
        );
        echo json_encode($response);
        exit;
      }
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }
  
  public function isValid($str){
    if(isset($str) && $str != null)
      return $str;
    else
      return '';
  }

  public function doCurlCall($url,$parameters){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 36000);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); 
    $result = curl_exec($ch);
    if(curl_errno($ch)){
      $error_msg = curl_error($ch);
      $response = array(
        'status' => "false",
        'msg' => "Invalid Service Call - "+$error_msg ,
        'result' => null
      );
      echo json_encode($response);
      exit;
    }
    return $result;
  }

  public function doCurlCallEko($url,$parameters,$requestType){   
    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_PORT => "25004",
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_POSTFIELDS => $parameters,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => $requestType,
    CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache",
        "developer_key: becbbce45f79c6f5109f848acd540567",
        "secret-key: MC6dKW278tBef+AuqL/5rW2K3WgOegF0ZHLW/FriZQw=",
        "secret-key-timestamp: 1516705204593"
      ),
    ));

    $result = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    if($err){
      $error_msg = $err;
      $response = array(
        'status' => "false",
        'msg' => "Invalid Service Call - "+$error_msg ,
        'result' => null
      );
      echo json_encode($response);
      exit;
    }
    return $result;
  }

  public function writeTxnOrderID($order_id){
    write_file('admin/txn_order_id.txt', $order_id."");
  }
}