<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

class LoginApi extends BaseController {
    /**
     * This is default constructor of the class
     */
    public function __construct() {
        parent::__construct();
        $this->load->model('loginApi_model');
    }

    /**
     * This function used as a login api
     */
    public function index() {
        
        $data =  json_decode(file_get_contents('php://input'), true);
     
        if (!empty($data['userName']) && !empty($data['passWord'])) {
            
            $username = $data['userName'];
            $password = $data['passWord'];

            $userdata = $this->loginApi_model->getAuthUser($username, $password);

            if ($userdata) {
                $userId = $userdata->userId;
                $roleId = $userdata->roleId;

                $date = date("Y-m-dh:i:s");

                $apiKey = md5($userId . $roleId . $date);

                $userInfo = array('user_id' => $userId, 'role_id' => $roleId, 'apiKey' => $apiKey);

                $result = $this->loginApi_model->setAuthUserToken($userInfo, $userId, $roleId);

                $result_response = array(
                    'user_id' => $userId,
                    'role_id' => $roleId,
                    'role_title' => $userdata->role,
                    'token' => $apiKey,
                    'first_name' => $userdata->first_name,
                    'last_name' => $userdata->last_name,
                    'mobile' => $userdata->mobile,
                    'email' => $userdata->email,
                    'username' => $userdata->username,
                    'storeName' => $userdata->store_name,
                    'profilePicId' => $userdata->profile_pic_id,
                    'walletBalance' => $userdata->wallet_balance
                );
                $response = array(
                    'status' => "true",
                    'msg' => "User logged in successfully.",
                    'result' => $result_response
                );
            } else {
                $response = array(
                    'status' => "false",
                    'msg' => "username or password not matched",
                    'result' => null
                );
            }
        }else{
            $response = array(
                'status' => "false",
                'msg' => "username or password invalid",
                'result' => null
            );
        }
        echo json_encode($response);
        exit;
    }
}

?>