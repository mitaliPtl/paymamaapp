<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';
require APPPATH . '/libraries/PaytmChecksum.php';

class Transactions extends BaseController {
    /**
     * This is default constructor of the class
     */
    public function __construct() {
        parent::__construct();
        $this->load->model('loginApi_model');
        $this->load->model('transactions_model');
        $this->load->model('rechargeApi_model');
        $this->load->helper('file');
    }

    public function index() {        
        
    }

    public function getAllTransctionByUser() {       
        $data =  json_decode(file_get_contents('php://input'), true);
        //autheticate user by token details begin
        if (!empty($data['token']) && !empty($data['user_id']) && !empty($data['role_id'])) {
            $user_id= $data['user_id'];
            $role_id= $data['role_id'];

            //authenticate user with their details
            if(!$this->loginApi_model->authenticateUser($data['user_id'],$data['role_id'],$data['token'])){
                $response = array(
                    'status' => "false",
                    'msg' => "Authetication failure with invalid token",
                    'result' => null
                );
                echo json_encode($response);
                exit;
            }
        }else{//if proper input not getting from the application           
            $response = array(
              'status' => "false",
              'msg' => "Authetication Failure",
              'result' => null
            );
            echo json_encode($response);
            exit;
        }
        //autheticate user by token details end
        if (!empty($data['serviceID'])){ //for recharge it is //Recharge
            $serviceID = $data['serviceID'];
            $reportType = "transactions";
            if(isset($data['reportType'])){
               $reportType = $data['reportType']; 
            }
            $transactions = $this->transactions_model->getAllTransactions($serviceID,$user_id,$reportType);
            if ($transactions) {
                $response = array(
                    'status' => "true",
                    'msg' => "All Transactions",
                    'result' => $transactions
                );
            }else{
                $response = array(
                    'status' => "false",
                    'msg' => "no data found",
                    'result' => null
                );
            }
        }
        else if(empty($data['serviceID'])){

            if(isset($data['reportType'])){
               $reportType = $data['reportType']; 
            }
            $transactions = $this->transactions_model->getAllTransactions_withoutserviceeid($user_id,$reportType);
            if ($transactions) {
                $response = array(
                    'status' => "true",
                    'msg' => "All Transactions",
                    'result' => $transactions
                );
            }else{
                $response = array(
                    'status' => "false",
                    'msg' => "no data found",
                    'result' => null
                );
            }
        }
        else{
            $response = array(
                'status' => "false",
                'msg' => "Please provide required inputs",
                'result' => null
            );
        }
        echo json_encode($response);
        exit;
    }
    public function getOneTransctionByUser() {
     $data =  json_decode(file_get_contents('php://input'), true);
        //autheticate user by token details begin
        if (!empty($data['token']) && !empty($data['user_id']) && !empty($data['role_id'])) {
            $user_id= $data['user_id'];
            $role_id= $data['role_id'];

            //authenticate user with their details
            if(!$this->loginApi_model->authenticateUser($data['user_id'],$data['role_id'],$data['token'])){
                $response = array(
                    'status' => "false",
                    'msg' => "Authetication failure with invalid token",
                    'result' => null
                );
                echo json_encode($response);
                exit;
            }
        }else{//if proper input not getting from the application           
            $response = array(
              'status' => "false",
              'msg' => "Authetication Failure",
              'result' => null
            );
            echo json_encode($response);
            exit;
        }
        //autheticate user by token details end
        if (!empty($data['serviceID']) && !empty($data['id'])){ //for recharge it is //Recharge
            $serviceID = $data['serviceID'];
            $reportType = "transactions";
            if(isset($data['reportType'])){
               $reportType = $data['reportType']; 
            }
            $id = $data['id'];
            $transactions = $this->transactions_model->getAllTransactions($serviceID,$user_id,$reportType,$id);
            if ($transactions) {
                $response = array(
                    'status' => "true",
                    'msg' => "One Transactions",
                    'result' => $transactions
                );
            }else{
                $response = array(
                    'status' => "false",
                    'msg' => "no data found",
                    'result' => null
                );
            }
        }
        
        else{
            $response = array(
                'status' => "false",
                'msg' => "Please provide required inputs",
                'result' => null
            );
        }
        echo json_encode($response);
        exit;
    }
    public function authenticateUser($data){
        //autheticate user by token details begin
        if (!empty($data['token']) && !empty($data['user_id']) && !empty($data['role_id'])) {
            $user_id= $data['user_id'];
            $role_id= $data['role_id'];

            //authenticate user with their details
            if(!$this->loginApi_model->authenticateUser($data['user_id'],$data['role_id'],$data['token'])){
                $response = array(
                    'status' => "false",
                    'msg' => "Authetication failure with invalid token",
                    'result' => null
                );
                echo json_encode($response);
                exit;
            }
      }else{//if proper input not getting from the application           
        $response = array(
            'status' => "false",
            'msg' => "Authetication Failure",
            'result' => null
        );
        echo json_encode($response);
        exit;
      }
      //autheticate user by token details end
  }
  
  /*public function getPaytmTransactionDetailsApi() {
    $data =  json_decode(file_get_contents('php://input'), true);
    $this->authenticateUser($data);         
    if(!empty($data['amount'])){
        $this->db->select('*');
        $this->db->from('tbl_payment_gateway_integation');
        $this->db->where('id', "1");
        $query = $this->db->get();
        $payment_dtls = $query->row();
        if($payment_dtls->environment == "testing"){
            //staging url
            $url = "https://securegw-stage.paytm.in/theia/api/v1/showPaymentPage";
        }else{
            //production url
            $url = "https://securegw.paytm.in/theia/api/v1/showPaymentPage";
        }
        $last_txn_id = file_get_contents("admin/txn_order_id.txt");              
        $orderId = intval($last_txn_id)+1;
        $this->writeTxnOrderID($orderId);
        $result = array(
          'merchant_id' => $payment_dtls->merchant_id,
          'paytm_txn_start_url' => $url."",
          'orderId' => $orderId."",
          'callbackurl' => base_url()."transactions/paytm_transaction_status/".$orderId
        );
        $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
        );
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;
  }*/

  public function paytm_transaction_status($orderID="") {
    $this->db->select('*');
    $this->db->from('tbl_payment_gateway_integation');
    $this->db->where('id', "1");
    $query = $this->db->get();
    $payment_dtls = $query->row();
    $mid = $payment_dtls->merchant_id;//"XtrSQa90965375513903";//"ASJCcA23692100733906";
    $merchantKey = $payment_dtls->working_key;//"Cw7UhxxDlP3x#IFf";//"9UtzE2DUArQnP5fy";
    $env = $payment_dtls->environment;
    $currency = $payment_dtls->currency;

    $paytmParams = array();
    $paytmParams["MID"]     = $mid;
    $paytmParams["ORDERID"] = $orderID;
    /*
    * Generate checksum by parameters we have
    * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
    */
    $checksum = PaytmChecksum::generateSignature($paytmParams, $merchantKey);
    $paytmParams["CHECKSUMHASH"] = $checksum;

    $post_data = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);
    if($env == "testing"){
        /* for Staging */
        $url = "https://securegw-stage.paytm.in/order/status";
    }else{
        /* for Production */
        $url = "https://securegw.paytm.in/order/status";
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));  
    $response = curl_exec($ch);
    print_r($response);
  }

  public function getPaytmTransactionApiGatewayDetails() {
    $data =  json_decode(file_get_contents('php://input'), true);
    $this->authenticateUser($data);         
    if(!empty($data['amount'])){
        $user_id = $data['user_id'];
        $amount = $data['amount'];

        $last_txn_id = file_get_contents("admin/txn_order_id.txt");              
        $order_id = intval($last_txn_id)+1;
        $this->writeTxnOrderID($order_id);

        $this->db->select('*');
        $this->db->from('tbl_payment_gateway_integation');
        $this->db->where('id', "1");
        $query = $this->db->get();
        $payment_dtls = $query->row();
        $mid = $payment_dtls->merchant_id;//"XtrSQa90965375513903";//"ASJCcA23692100733906";
        $merchantKey = $payment_dtls->working_key;//"Cw7UhxxDlP3x#IFf";//"9UtzE2DUArQnP5fy";
        $env = $payment_dtls->environment;
        $currency = $payment_dtls->currency;

        $paytmParams = array();
        if($env == "testing"){
            //staging
            $callback_url = "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=".$order_id."";
        }else{
            //production
            $callback_url = "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID=".$order_id."";
        }
        $paytmParams["body"] = array(
            "requestType"   => "Payment",
            "mid"           => $mid,
            "websiteName"   => "WEBSTAGING",
            "orderId"       => $order_id,
            "callbackUrl"   => $callback_url,
            "txnAmount"     => array(
                "value"     => $amount,
                "currency"  => $currency,
            ),
            "userInfo"      => array(
                "custId"    => $user_id,
            ),
        );
        /*
        * Generate checksum by parameters we have in body
        * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
        */
        $checksum = PaytmChecksum::generateSignature(json_encode($paytmParams["body"], JSON_UNESCAPED_SLASHES), 
            $merchantKey);
        $paytmParams["head"] = array(
            "signature" => $checksum
        );

        $post_data = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);
        //echo $post_data;
        //die;
        if($env == "testing"){
            /* for Staging */
            $url = "https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid=".$mid."&orderId=".$order_id;
        }else{
            /* for Production */
            $url = "https://securegw.paytm.in/theia/api/v1/initiateTransaction?mid=".$mid."&orderId=".$order_id;
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json")); 
        $response1 = curl_exec($ch);
        //$response2 = json_decode($response1,true);
        //print_r($response);
        if($payment_dtls->environment == "testing"){
            //staging url
            $paymenturl = "https://securegw-stage.paytm.in/theia/api/v1/showPaymentPage";
        }else{
            //production url
            $paymenturl = "https://securegw.paytm.in/theia/api/v1/showPaymentPage";
        }
        $result = array(
            'orderId' => $order_id,
            'merchant_id' => $mid,
            'callbackurl' => base_url()."transactions/paytm_transaction_status/".$order_id,
            'paytm_txn_start_url' => $paymenturl."",
            'response' => $response1.""
        );
        $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
        );
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    exit;    
  }
 public function getupiPaytmTransactionApiGatewayDetails() {
    $data =  json_decode(file_get_contents('php://input'), true);
    //print_r($data);
    $this->authenticateUser($data);         
    if(!empty($data['amount'])){
        $user_id            = $data['user_id'];
        $amount             = $data['amount'];
        $payment_type       =$data['payment_type'];
        $last_txn_id = file_get_contents("admin/txn_order_id.txt");              
        $order_id = intval($last_txn_id)+1;
        $this->writeTxnOrderID($order_id);

        $this->db->select('*');
        $this->db->from('tbl_payment_gateway_integation');
        $this->db->where('id', "1");
        $query = $this->db->get();
        $payment_dtls = $query->row();
        $mid='HGNciO20688378643295';
        //$mid = $payment_dtls->merchant_id;//"XtrSQa90965375513903";//"ASJCcA23692100733906";
        $merchantKey = $payment_dtls->working_key;//"Cw7UhxxDlP3x#IFf";//"9UtzE2DUArQnP5fy";
        $env = $payment_dtls->environment;
        $currency = $payment_dtls->currency;

        $paytmParams = array();
        if($env == "testing"){
            //staging
            $callback_url = "https://securegw-stage.paytm.in/theia/api/v1/processTransaction?mid=YOUR_MID_HERE&orderId=".$order_id."";
        }else{
            //production
            $callback_url = "https://securegw.paytm.in/theia/api/v1/processTransaction?mid=YOUR_MID_HERE&orderId".$order_id."";
        }
        $paytmParams["body"] = array(
            "requestType"   => "Payment",
            "mid"           => $mid,
            "websiteName"   => "WEBSTAGING",
            "orderId"       => $order_id,
            "callbackUrl"   => $callback_url,
            "txnAmount"     => array(
                "value"     => $amount,
                "currency"  => $currency,
            ),
            "userInfo"      => array(
                "custId"    => $user_id,
            ),
        );
        /*
        * Generate checksum by parameters we have in body
        * Find your Merchant Key in your Paytm Dashboard at https://dashboard.paytm.com/next/apikeys 
        */
        $checksum = PaytmChecksum::generateSignature(json_encode($paytmParams["body"], JSON_UNESCAPED_SLASHES), 
            $merchantKey);
        $paytmParams["head"] = array(
            "signature" => $checksum
        );

        $post_data = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);
        //echo $post_data;
        //die;
        //if($env == "testing"){
            /* for Staging */
            //$url = "https://securegw-stage.paytm.in/theia/api/v1/initiateTransaction?mid=".$mid."&orderId=".$order_id;
        //}else{
            /* for Production */
            $url = "https://securegw.paytm.in/theia/api/v1/initiateTransaction?mid=".$mid."&orderId=".$order_id;
        //}

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json")); 
        $response1 = curl_exec($ch);
        $response2 = json_decode($response1,true);
        //print_r($response1);
        $txntoken=$response2['body']['txnToken'];
        $payresponse=$this->transprocess($txntoken,$mid,$order_id,$payment_type);
        print_r($payresponse);
        if($payment_dtls->environment == "testing"){
            //staging url
            $paymenturl = "https://securegw-stage.paytm.in/theia/api/v1/showPaymentPage";
        }else{
            //production url
            $paymenturl = "https://securegw.paytm.in/theia/api/v1/showPaymentPage";
        }
        $result = array(
            'orderId' => $order_id,
            'merchant_id' => $mid,
            'callbackurl' => base_url()."transactions/paytm_transaction_status/".$order_id,
            'paytm_txn_start_url' => $paymenturl."",
            'response' => $response1.""
        );
        $response = array(
            'status' => "true",
            'msg' => "Success",
            'result' => $result
        );
    }else{
      $response = array(
        'status' => "false",
        'msg' => "Invalid Request",
        'result' => null
      );
    }
    echo json_encode($response);
    //exit;    
  }
  public function test(){
    
    $names=array('id'=>'1','name'=>'susmitha');
    //print_r($names);
    $ss=json_encode($names);
    $json = json_decode($ss, true);
    // print_r($ss);
    // echo $json['name'];

//date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
//echo date('d-m-Y H:i:s');

    //echo date('d-m-Y h:i:m a');
    echo "<br>";
$amount=6000;
   echo $charge=$amount*(0.6/100);
 echo "<br>";
   $app    =$this->rechargeApi_model->getTDS();
   echo $TDS     =$amount*(0.4/100)*($app->value/100);
    echo "<br>";
   echo $totalcharge=$charge+$TDS;
    echo "<br>";
   echo $Checkamountinwallet =$amount +$totalcharge;
    echo "<br>";
    
  }
  public function transprocess(){
    $txntoken='1b287ffcfd80447ca3baab2028cf52901600846619499';
    $mid='hLxOON82408810393323';
    $order_id='3112';
    $payment_type='UPI_INTENT';
$paytmParams = array();

$paytmParams["body"] = array(
    "requestType" => "NATIVE",
    "mid"         => $mid,
    "orderId"     => $order_id,
    "paymentMode" =>$payment_type,
    
);

$paytmParams["head"] = array(
    "txnToken"    => $txntoken
);

$post_data = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);

/* for Staging */
 echo $url = "https://securegw-stage.paytm.in/theia/api/v1/processTransaction?mid=".$mid."&orderId=".$order_id."";

/* for Production */
 //echo $url = "https://securegw.paytm.in/theia/api/v1/processTransaction?mid=".$mid."&orderId=".$order_id."";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json")); 
$response = curl_exec($ch);
print_r($response);
//return $response;
  }
  public function writeTxnOrderID($order_id){
    write_file('admin/txn_order_id.txt', $order_id."");
  }
}

?>